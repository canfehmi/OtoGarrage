﻿namespace CompanyService.Dtos.SectorDto
{
    public class DeleteSectorDto
    {
        public int Id { get; set; }

        public DeleteSectorDto(int id)
        {
            Id = id;
        }
    }
}
