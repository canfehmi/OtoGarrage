﻿namespace CompanyService.Dtos.ModelDto
{
    public class DeleteModelDto
    {
        public int Id { get; set; }

        public DeleteModelDto(int id)
        {
            Id = id;
        }
    }
}
