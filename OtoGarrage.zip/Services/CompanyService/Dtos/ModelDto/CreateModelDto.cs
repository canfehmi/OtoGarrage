﻿using CompanyService.Entities;

namespace CompanyService.Dtos.ModelDto
{
    public class CreateModelDto
    {
        public string ModelName { get; set; } = default!;
    }
}
